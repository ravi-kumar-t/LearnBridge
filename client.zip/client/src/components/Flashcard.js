// client/src/components/Flashcard.js
import React from 'react';

function Flashcard({ title, description, iconSrc }) { // Added iconSrc prop if you have image icons
  return (
    // Applied styling for white background, rounded corners, shadow, padding, and hover
    <div className="bg-card-light-bg rounded-xl shadow-lg p-6 flex flex-col items-center text-center transition-all duration-300 hover:shadow-xl hover:bg-card-accent-bg border border-card-border"> {/* Added border and hover bg */}
      {/* Optional: Render an icon if provided */}
      {iconSrc && (
        <img src={iconSrc} alt={`${title} icon`} className="h-16 w-16 mb-4 object-contain" /> // Adjust size as needed
      )}
      {/* If you prefer Font Awesome icons, you'd integrate them here */}

      <h4 className="text-xl font-bold text-gray-900 mb-2">{title}</h4>
      <p className="text-gray-700 text-base">{description}</p>
    </div>
  );
}

export default Flashcard;