// client/src/components/Header.js
import React from 'react';
import { Link } from 'react-router-dom';
// Import Clerk components for displaying user status/buttons
import { SignedIn, SignedOut, UserButton } from '@clerk/clerk-react'; 

function Header() {
  return (
    <nav className="bg-white shadow-md py-4 fixed w-full z-10 top-0">
      <div className="container mx-auto px-4 flex justify-between items-center">
        <Link to="/" className="text-2xl font-bold text-blue-600">
          LearnBridge
        </Link>
        <div className="flex space-x-6 items-center">
          {/* Reordered Navigation Links */}
          <Link to="/" className="text-gray-700 hover:text-blue-600">Home</Link>
          <Link to="/courses" className="text-gray-700 hover:text-blue-600">Courses</Link>
          <Link to="/explore" className="text-gray-700 hover:text-blue-600">AI Tools</Link> {/* Moved AI Tools here */}
          <Link to="/about" className="text-gray-700 hover:text-blue-600">About</Link>
          <Link to="/contact" className="text-gray-700 hover:text-blue-600">Contact</Link>
          
          {/* REMOVED: Dashboard link as requested */}
          {/* <Link to="/dashboard" className="text-gray-700 hover:text-blue-600">Dashboard</Link> */}

          {/* Clerk's Authentication UI (remains at the end) */}
          <SignedIn>
            <UserButton afterSignOutUrl="/" />
          </SignedIn>
          <SignedOut>
            <Link to="/sign-in" className="bg-blue-600 text-white px-4 py-2 rounded-md hover:bg-blue-700 transition">
              Sign In
            </Link>
            <Link to="/sign-up" className="text-blue-600 border border-blue-600 px-4 py-2 rounded-md hover:bg-blue-50 transition">
              Sign Up
            </Link>
          </SignedOut>
        </div>
      </div>
    </nav>
  );
}

export default Header;