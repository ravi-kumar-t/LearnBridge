// client/src/components/Footer.js
import React from 'react';
// If you plan to use Font Awesome, uncomment these and install:
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faMapMarkerAlt, faEnvelope, faPhone } from '@fortawesome/free-solid-svg-icons';
import { faGithub, faInstagram, faLinkedin } from '@fortawesome/free-brands-svg-icons'; // Import brand icons

function Footer() {
  return (
    <footer className="bg-gray-800 text-white p-8 mt-10">
      <div className="container mx-auto grid grid-cols-1 md:grid-cols-3 gap-8">
        <div className="footer-section quick-links">
          <h3 className="text-xl font-semibold mb-4">Quick Links</h3>
          <ul className="space-y-2">
            <li><a href="/" className="text-gray-400 hover:text-white transition duration-300">About Us</a></li>
            <li><a href="/contact" className="text-gray-400 hover:text-white transition duration-300">Contact Us</a></li>
            <li><a href="/focus-mode" className="text-gray-400 hover:text-white transition duration-300">Focus Mode</a></li>
            <li><a href="/testimonials" className="text-gray-400 hover:text-white transition duration-300">Testimonials</a></li>
          </ul>
        </div>
        <div className="footer-section connect">
          <h3 className="text-xl font-semibold mb-4">Connect With Us</h3>
          <p className="text-gray-400 mb-2">
            <FontAwesomeIcon icon={faMapMarkerAlt} className="mr-2" />
            Visakhapatnam, Andhra Pradesh, India
          </p>
          <p className="text-gray-400 mb-2">
            <FontAwesomeIcon icon={faPhone} className="mr-2" />
            +91 80197 88123
          </p>
          <p className="text-gray-400 mb-2">
            <FontAwesomeIcon icon={faEnvelope} className="mr-2" />
            ravikumartekkali2006@gmail.com
          </p>
          <div className="flex space-x-4 mt-4">
            <a href="https://github.com/your-github" target="_blank" rel="noopener noreferrer" className="text-gray-400 hover:text-white transition duration-300">
              <FontAwesomeIcon icon={faGithub} size="2x" />
            </a>
            <a href="https://instagram.com/your-instagram" target="_blank" rel="noopener noreferrer" className="text-gray-400 hover:text-white transition duration-300">
              <FontAwesomeIcon icon={faInstagram} size="2x" />
            </a>
            <a href="https://linkedin.com/in/your-linkedin" target="_blank" rel="noopener noreferrer" className="text-gray-400 hover:text-white transition duration-300">
              <FontAwesomeIcon icon={faLinkedin} size="2x" />
            </a>
          </div>
        </div>
        <div className="footer-section about">
          <h3 className="text-xl font-semibold mb-4">About Code Ki Duniya</h3>
          <p className="text-gray-400 leading-relaxed">
            We are dedicated to providing high-quality programming education to everyone. Our platform offers free courses, tutorials, and resources to help you master coding skills.
          </p>
        </div>
      </div>
      <div className="border-t border-gray-700 mt-8 pt-6 text-center text-gray-500">
        &copy; 2025 LearnBridge. All Rights Reserved.
        <p className="mt-2">Made with <span style={{ color: 'red' }}>&hearts;</span> in India</p>
      </div>
    </footer>
  );
}

export default Footer;