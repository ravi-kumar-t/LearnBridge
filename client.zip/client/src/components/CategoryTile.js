// client/src/components/CategoryTile.js
import React from 'react';

// Added onClick prop
function CategoryTile({ imageSrc, title, onClick }) {
  return (
    // Make the entire div clickable and apply hover effects
    <div
      className="bg-white rounded-lg shadow-md p-4 flex flex-col items-center text-center cursor-pointer
                 hover:shadow-lg hover:scale-105 transition-all duration-300 transform"
      onClick={() => onClick(title)} // Call onClick with the tile's title
    >
      <img src={imageSrc} alt={title} className="w-16 h-16 object-contain mb-2" />
      <h4 className="text-md font-semibold text-gray-800">{title}</h4>
    </div>
  );
}

export default CategoryTile;