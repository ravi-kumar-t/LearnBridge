// client/src/pages/CareerRecommendationPage.js
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import Markdown from 'react-markdown';

function CareerRecommendationPage() {
  const [userInput, setUserInput] = useState('');
  const [inferredInterests, setInferredInterests] = useState(''); // State for extracted inferred interests
  const [recommendation, setRecommendation] = useState(''); // State for the rest of the recommendation
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState(null);

  const navigate = useNavigate();

  const handleGenerateRecommendation = async () => {
    setIsLoading(true);
    setError(null);
    setInferredInterests('');
    setRecommendation('');

    if (!userInput.trim()) {
      setError("Please provide your skills, technologies, or keywords.");
      setIsLoading(false);
      return;
    }

    try {
      const response = await fetch('http://localhost:5000/api/career-recommendation', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ userInput: userInput }),
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || 'Something went wrong with generating the career recommendation.');
      }

      const data = await response.json();
      const fullRecommendation = data.recommendation;

      // --- Robust Parsing of Gemini's Structured Response ---
      const sections = {};
      // This regex captures the heading (e.g., "**I. Inferred Interests**") and the content that follows,
      // up until the next heading or the end of the string.
      const sectionRegex = /\*\*(I|II|III|IV|V|VI|VII)\. (.*?)\*\*\s*([\s\S]*?)(?=(?:\*\*(?:I|II|III|IV|V|VI|VII)\. .*?\*\*)|$)/g;
      let match;

      while ((match = sectionRegex.exec(fullRecommendation)) !== null) {
        const sectionHeading = `**${match[1]}. ${match[2]}**`; // Reconstruct the full markdown heading
        const sectionContent = match[3].trim(); // Get the content
        sections[sectionHeading] = sectionContent; // Store it with its full markdown heading as key
      }

      // 1. Extract and set Inferred Interests
      const inferredInterestsHeading = '**I. Inferred Interests**';
      if (sections[inferredInterestsHeading]) {
        setInferredInterests(sections[inferredInterestsHeading]);
      } else {
        setInferredInterests("Could not find 'Inferred Interests' section.");
      }

      // 2. Build the main recommendation content from Section II onwards
      let mainRecommendationContent = '';
      const orderedHeadings = [
        '**II. Recommended Career Path**',
        '**III. Essential Skill Sets**',
        '**IV. Technologies to Learn**',
        '**V. Resources for Learning**',
        '**VI. Job Market Insights (General Trends)**',
        '**VII. Action Plan**'
      ];

      orderedHeadings.forEach(heading => {
        if (sections[heading]) {
          // Re-add the heading in markdown format, followed by its content
          mainRecommendationContent += `${heading}\n${sections[heading]}\n\n`;
        }
      });

      setRecommendation(mainRecommendationContent.trim());

    } catch (err) {
      setError(err.message);
      console.error("Error fetching career recommendation:", err);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="container mx-auto p-8 pt-16 min-h-screen bg-gray-100">
      {/* Back button */}
      <div className="flex justify-start mb-6">
        <button
          onClick={() => navigate('/explore')}
          className="flex items-center text-blue-600 hover:text-blue-800 font-medium px-4 py-2 rounded-lg border border-blue-600 hover:border-blue-800 transition-colors duration-200"
        >
          <svg className="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M10 19l-7-7m0 0l7-7m-7 7h18"></path></svg>
          Back to Explore
        </button>
      </div>

      <h1 className="text-3xl font-bold text-gray-800 mb-6 text-center">AI Career Recommendation System</h1>
      <p className="text-lg text-gray-600 mb-8 text-center">
        Enter your skills, technologies, and interests below. Our AI will infer your potential interests and suggest a personalized career path, roadmap, and learning resources.
      </p>

      <div className="max-w-4xl mx-auto bg-white p-8 rounded-lg shadow-md flex flex-col md:flex-row gap-8">
        {/* Input Section */}
        <div className="flex-1">
          <div className="mb-6">
            <label htmlFor="userInput" className="block text-gray-700 text-sm font-bold mb-2">
              Your Skills, Technologies, and Keywords:
            </label>
            <textarea
              id="userInput"
              className="shadow appearance-none border rounded w-full py-3 px-4 text-gray-700 leading-tight focus:outline-none focus:ring-2 focus:ring-blue-500 h-32"
              placeholder="e.g., HTML, CSS, JavaScript, React.js, Python, Data Analysis, Cloud Computing..."
              value={userInput}
              onChange={(e) => setUserInput(e.target.value)}
            ></textarea>
          </div>

          <div className="flex justify-center mb-6 md:mb-0">
            <button
              onClick={handleGenerateRecommendation}
              disabled={isLoading || !userInput.trim()}
              className={`bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 px-6 rounded-lg transition duration-300 ${isLoading || !userInput.trim() ? 'opacity-50 cursor-not-allowed' : ''}`}
            >
              {isLoading ? 'Generating Recommendation...' : 'Generate Recommendation'}
            </button>
          </div>

          {/* SECTION: Display Inferred Interests Separately */}
          {inferredInterests && !error && ( // Only show if interests are found and no error
            <div className="mt-6 p-4 bg-purple-50 border border-purple-200 rounded-lg shadow-inner">
              <h3 className="text-lg font-semibold text-purple-800 mb-2">Inferred Interests:</h3>
              <div className="prose max-w-none text-gray-800">
                <Markdown>{inferredInterests}</Markdown>
              </div>
            </div>
          )}
          {/* Ensure error message is below the button if no other output */}
          {error && (
            <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative mt-4" role="alert">
              <strong className="font-bold">Error:</strong>
              <span className="block sm:inline"> {error}</span>
            </div>
          )}
        </div>


        {/* Output Section for Main Recommendation */}
        <div className="flex-1">
          <h3 className="text-xl font-semibold text-gray-700 mb-4">Recommended Career Path & Details:</h3>
          {recommendation && !error && ( // Only show if recommendation is found and no error
            <div className="mt-4 p-6 bg-blue-50 border border-blue-200 rounded-lg shadow-inner prose max-w-none">
              <Markdown>{recommendation}</Markdown>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

export default CareerRecommendationPage;