// client/src/pages/AIHomeworkHelperPage.js
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom'; // For the back button

function AIHomeworkHelperPage() {
  const [problemText, setProblemText] = useState('');
  const [explanation, setExplanation] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const navigate = useNavigate(); // Initialize useNavigate

  const handleGenerateExplanation = async () => {
    if (problemText.trim() === '') {
      setError('Please enter a problem to get an explanation.');
      return;
    }

    setLoading(true);
    setError('');
    setExplanation(''); // Clear previous explanation

    try {
      const response = await fetch('http://localhost:5000/api/homework-helper', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ problem: problemText }),
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || 'Failed to get explanation from the server.');
      }

      const data = await response.json();
      setExplanation(data.explanation);

    } catch (err) {
      console.error('Error generating explanation:', err);
      setError('Failed to get homework explanation. Please try again. ' + err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="container mx-auto p-8 pt-16 min-h-screen bg-gray-100">
      {/* Back button */}
      <div className="flex justify-start mb-6">
        <button
          onClick={() => navigate('/explore')}
          className="flex items-center text-blue-600 hover:text-blue-800 font-medium px-4 py-2 rounded-lg border border-blue-600 hover:border-blue-800 transition-colors duration-200"
        >
          <svg className="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M10 19l-7-7m0 0l7-7m-7 7h18"></path></svg>
          Back to Explore
        </button>
      </div>

      <h1 className="text-3xl font-bold text-gray-800 mb-6 text-center">AI Homework Helper</h1>
      <p className="text-lg text-gray-600 mb-8 text-center">
        Enter your math or science problem below, and get a step-by-step explanation.
      </p>

      <div className="max-w-4xl mx-auto bg-white p-8 rounded-lg shadow-md mb-8">
        <div className="mb-6">
          <label htmlFor="problemInput" className="block text-lg font-medium text-gray-700 mb-2">
            Your Problem:
          </label>
          <textarea
            id="problemInput"
            className="w-full p-4 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500 transition duration-150 ease-in-out text-gray-800 resize-y h-32"
            placeholder="E.g., 'Solve for x: 2x + 5 = 15' or 'Explain the process of photosynthesis.'"
            value={problemText}
            onChange={(e) => setProblemText(e.target.value)}
          ></textarea>
        </div>

        <button
          onClick={handleGenerateExplanation}
          className="w-full bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 px-4 rounded-md transition duration-300 ease-in-out transform hover:scale-105 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2"
          disabled={loading || !problemText.trim()}
        >
          {loading ? (
            <span className="flex items-center justify-center">
              <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
              </svg>
              Getting Explanation...
            </span>
          ) : (
            'Get Explanation'
          )}
        </button>

        {error && (
          <p className="text-red-600 mt-4 text-center">{error}</p>
        )}
      </div>

      {explanation && (
        <div className="max-w-4xl mx-auto bg-white p-8 rounded-lg shadow-md mt-8">
          <h3 className="text-2xl font-bold text-gray-800 mb-4">Explanation:</h3>
          <div className="prose lg:prose-lg max-w-none text-gray-700" dangerouslySetInnerHTML={{ __html: explanation.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>').replace(/\n/g, '<br/>') }}>
            {/* The dangerouslySetInnerHTML is used here to render markdown-like bolding and new lines */}
          </div>
        </div>
      )}
    </div>
  );
}

export default AIHomeworkHelperPage;