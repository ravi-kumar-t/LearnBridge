// client/src/pages/Contact.js
import React, { useState } from 'react'; // Import useState
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faMapMarkerAlt, faEnvelope, faPhone } from '@fortawesome/free-solid-svg-icons';
import axios from 'axios'; // Import axios for easier HTTP requests

function Contact() {
  // State for form fields
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    subject: '',
    message: ''
  });
  const [submissionStatus, setSubmissionStatus] = useState(null); // 'success', 'error', 'submitting'

  // Handle input changes
  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  // Handle form submission
  const handleSubmit = async (e) => {
    e.preventDefault(); // Prevent default form submission (page reload)
    setSubmissionStatus('submitting');
    try {
      // Send data to your backend API endpoint
      const response = await axios.post('http://localhost:5000/api/contact', formData); // Adjust URL if your backend is different

      if (response.status === 200) { // Assuming your backend sends 200 on success
        setSubmissionStatus('success');
        setFormData({ name: '', email: '', subject: '', message: '' }); // Clear form
      } else {
        setSubmissionStatus('error');
      }
    } catch (error) {
      console.error("Error submitting contact form:", error);
      setSubmissionStatus('error');
    }
  };

  return (
    <section className="py-16 bg-gray-50">
      <div className="container mx-auto px-4 text-center">
        {/* Top Section: "CONTACT US" and "Get In Touch" */}
        <p className="text-sm font-semibold text-purple-600 uppercase tracking-wide mb-2">
          CONTACT US
        </p>
        <h1 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4">
          Get In Touch
        </h1>
        <p className="text-lg text-gray-700 mb-12 max-w-2xl mx-auto">
          Have questions? We'd love to hear from you. Send us a message and we'll respond as soon as possible.
        </p>

        {/* Three Contact Info Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-16 max-w-5xl mx-auto">
          {/* Visit Us Card - UPDATED */}
          <div className="bg-white p-8 rounded-xl shadow-lg flex flex-col items-center">
            <div className="w-16 h-16 bg-purple-100 rounded-full flex items-center justify-center mb-4">
              <FontAwesomeIcon icon={faMapMarkerAlt} className="text-purple-600 text-3xl" />
            </div>
            <h3 className="text-xl font-semibold text-gray-900 mb-2">Visit Us</h3>
            <p className="text-gray-700 text-center">Lovely Professional University,</p>
            <p className="text-gray-700 text-center">Punjab, IN</p>
          </div>

          {/* Email Us Card - UPDATED */}
          <div className="bg-white p-8 rounded-xl shadow-lg flex flex-col items-center">
            <div className="w-16 h-16 bg-purple-100 rounded-full flex items-center justify-center mb-4">
              <FontAwesomeIcon icon={faEnvelope} className="text-purple-600 text-3xl" />
            </div>
            <h3 className="text-xl font-semibold text-gray-900 mb-2">Email Us</h3>
            <p className="text-gray-700 text-center">ravikumartekkali2006@gmail.com</p>
            <p className="text-gray-700 text-center">support@elearning.com</p>
          </div>

          {/* Call Us Card - UPDATED */}
          <div className="bg-white p-8 rounded-xl shadow-lg flex flex-col items-center">
            <div className="w-16 h-16 bg-purple-100 rounded-full flex items-center justify-center mb-4">
              <FontAwesomeIcon icon={faPhone} className="text-purple-600 text-3xl" />
            </div>
            <h3 className="text-xl font-semibold text-gray-900 mb-2">Call Us</h3>
            <p className="text-gray-700 text-center">+91 8019788123</p>
            <p className="text-gray-700 text-center">Mon-Fri, 9:00 AM - 6:00 PM</p>
          </div>
        </div>

        {/* Contact Form */}
        <div className="max-w-3xl mx-auto bg-white p-8 md:p-12 rounded-xl shadow-lg">
          <h3 className="text-2xl font-semibold text-gray-900 mb-6 text-center">Send us a Message</h3>
          <form onSubmit={handleSubmit} className="space-y-6"> {/* <--- ADDED onSubmit */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* Name Input */}
              <div>
                <label htmlFor="name" className="block text-gray-700 text-sm font-medium mb-2">Your Name</label>
                <input
                  type="text"
                  id="name"
                  name="name" // <--- IMPORTANT: Added name attribute
                  className="w-full p-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  placeholder="John Doe"
                  value={formData.name} // <--- Controlled component
                  onChange={handleChange} // <--- Handle change
                  required
                />
              </div>
              {/* Email Input */}
              <div>
                <label htmlFor="email" className="block text-gray-700 text-sm font-medium mb-2">Your Email</label>
                <input
                  type="email"
                  id="email"
                  name="email" // <--- IMPORTANT: Added name attribute
                  className="w-full p-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  placeholder="john.doe@example.com"
                  value={formData.email}
                  onChange={handleChange}
                  required
                />
              </div>
            </div>
            {/* Subject Input */}
            <div>
              <label htmlFor="subject" className="block text-gray-700 text-sm font-medium mb-2">Subject</label>
              <input
                type="text"
                id="subject"
                name="subject" // <--- IMPORTANT: Added name attribute
                className="w-full p-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                placeholder="Inquiry about courses"
                value={formData.subject}
                onChange={handleChange}
                required
              />
            </div>
            {/* Message Textarea */}
            <div>
              <label htmlFor="message" className="block text-gray-700 text-sm font-medium mb-2">Your Message</label>
              <textarea
                id="message"
                name="message" // <--- IMPORTANT: Added name attribute
                rows="5"
                className="w-full p-3 border border-gray-300 rounded-lg focus:outline-none focus:shadow-outline resize-y focus:ring-2 focus:ring-blue-500"
                placeholder="Type your message here..."
                value={formData.message}
                onChange={handleChange}
                required
              ></textarea>
            </div>
            {/* Submission Status Message */}
            {submissionStatus === 'submitting' && (
              <p className="text-blue-600 text-center">Sending message...</p>
            )}
            {submissionStatus === 'success' && (
              <p className="text-green-600 text-center">Message sent successfully!</p>
            )}
            {submissionStatus === 'error' && (
              <p className="text-red-600 text-center">Failed to send message. Please try again.</p>
            )}
            {/* Submit Button */}
            <button
              type="submit"
              className="bg-blue-600 hover:bg-blue-700 text-white font-semibold py-3 px-8 rounded-lg shadow-md transition duration-300 w-full"
              disabled={submissionStatus === 'submitting'} // Disable button during submission
            >
              Send Message
            </button>
          </form>
        </div>
      </div>
    </section>
  );
}

export default Contact;