// client/src/pages/Courses.js
import React, { useState, useEffect, useRef } from 'react';
import axios from 'axios';
import CategoryTile from '../components/CategoryTile';
import CourseCard from '../components/CourseCard';

// Replace with your actual YouTube Data API Key
const YOUTUBE_API_KEY = 'AIzaSyALTILXbWeheSAgHK6s0WAYn_mVjKnToDU'; 

function Courses() {
  const [courses, setCourses] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [currentQuery, setCurrentQuery] = useState("Python programming tutorial"); 
  const [searchInput, setSearchInput] = useState("");

  const coursesSectionRef = useRef(null);

  // Function to fetch videos from YouTube Data API
  const fetchYouTubeVideos = async (query) => {
    setCurrentQuery(query); 
    setLoading(true);
    setError(null);
    try {
      const response = await axios.get('https://www.googleapis.com/youtube/v3/search', {
        params: {
          key: YOUTUBE_API_KEY,
          part: 'snippet',
          q: query,
          type: 'video',
          maxResults: 12, 
          order: 'relevance', 
          videoDuration: 'long', 
        },
      });

      const fetchedCourses = response.data.items.map(item => ({
        id: item.id.videoId,
        imageUrl: item.snippet.thumbnails.high.url,
        title: item.snippet.title,
        description: item.snippet.description,
        instructor: item.snippet.channelTitle,
        rating: 'N/A', 
        reviews: 'N/A', 
        price: 'Free', 
        courseLink: `https://www.youtube.com/watch?v=$${item.id.videoId}`, 
      }));

      setCourses(fetchedCourses);
      
      // Removed the scroll logic from here.
      // It will now only be triggered by user actions.

    } catch (err) {
      console.error("Error fetching YouTube videos:", err);
      if (err.response && err.response.status === 403) {
        setError("API Error: Access Forbidden. Check your API key restrictions or daily quota.");
      } else if (err.response && err.response.status === 400) {
        setError("API Error: Bad Request. Check your API parameters.");
      } else {
        setError("Failed to fetch courses. Please try again later.");
      }
    } finally {
      setLoading(false);
    }
  };

  const handleSearchInputChange = (event) => {
    setSearchInput(event.target.value);
  };

  // Modified: Handle search button click or Enter key press
  const handleSearch = () => {
    if (searchInput.trim()) {
      fetchYouTubeVideos(searchInput.trim());
      // NEW: Scroll after search is initiated
      setTimeout(() => { // Small delay to ensure render before scroll
        if (coursesSectionRef.current) {
          coursesSectionRef.current.scrollIntoView({ behavior: 'smooth', block: 'start' });
        }
      }, 100);
    }
  };

  // NEW: Helper function for category clicks, to also trigger scroll
  const handleCategoryClick = (query) => {
    fetchYouTubeVideos(query);
    setTimeout(() => { // Small delay to ensure render before scroll
      if (coursesSectionRef.current) {
        coursesSectionRef.current.scrollIntoView({ behavior: 'smooth', block: 'start' });
      }
    }, 100);
  };

  // Fetch videos only on initial mount for default content, no scroll
  useEffect(() => {
    fetchYouTubeVideos(currentQuery); 
  }, []); // Empty dependency array: runs only once on mount

  return (
    <div className="py-8">
      {/* Search Bar Section */}
      <section className="bg-blue-600 py-12 text-white">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">Find Your Next Course!</h2>
          <p className="text-lg mb-6">Select a category below or use the search bar to explore thousands of free courses.</p>
          <div className="flex justify-center items-center gap-2 max-w-xl mx-auto">
            <input
              type="text"
              placeholder="e.g., Data Structures, Web Development, Calculus"
              className="w-full p-3 rounded-lg border border-gray-300 text-gray-800 focus:outline-none focus:ring-2 focus:ring-blue-400"
              value={searchInput}
              onChange={handleSearchInputChange}
              onKeyDown={(e) => {
                if (e.key === 'Enter') {
                  handleSearch();
                }
              }}
            />
            <button
              onClick={handleSearch}
              className="bg-white text-blue-600 font-bold py-3 px-6 rounded-lg hover:bg-gray-100 transition duration-300"
            >
              Search
            </button>
          </div>
        </div>
      </section>

      {/* Categories Section - Now triggers searches */}
      <section className="bg-gray-100 py-16">
        <div className="container mx-auto px-4 text-center">
          <h3 className="text-2xl font-semibold text-blue-600 mb-2">Categories</h3>
          <h2 className="text-4xl font-bold text-gray-900 mb-12">Popular Courses to explore</h2>
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-6">
            {/* Call new handleCategoryClick */}
            <CategoryTile imageSrc="/images/python-icon.png" title="Python" onClick={() => handleCategoryClick("Python programming tutorial")} />
            <CategoryTile imageSrc="/images/javascript-icon.png" title="JavaScript" onClick={() => handleCategoryClick("JavaScript full course")} />
            <CategoryTile imageSrc="/images/java-icon.png" title="Java" onClick={() => handleCategoryClick("Java comprehensive tutorial")} />
            <CategoryTile imageSrc="/images/html-css-icon.png" title="HTML CSS" onClick={() => handleCategoryClick("HTML CSS responsive design tutorial")} />
            <CategoryTile imageSrc="/images/react-icon.png" title="React" onClick={() => handleCategoryClick("React JS complete course")} />
            <CategoryTile imageSrc="/images/node-icon.png" title="Node.js" onClick={() => handleCategoryClick("Node JS backend development")} />
            
            <CategoryTile imageSrc="/images/dbms-icon.png" title="DBMS" onClick={() => handleCategoryClick("Database Management Systems full course")} />
            <CategoryTile imageSrc="/images/data-structures-icon.png" title="Data Structures" onClick={() => handleCategoryClick("Data Structures and Algorithms full course")} />
            <CategoryTile imageSrc="/images/cloud-icon.png" title="Cloud Computing" onClick={() => handleCategoryClick("Cloud Computing fundamentals tutorial")} />
            <CategoryTile imageSrc="/images/ai-ml-icon.png" title="AI/ML" onClick={() => handleCategoryClick("Artificial Intelligence Machine Learning course")} />
            <CategoryTile imageSrc="/images/cybersecurity-icon.png" title="Cybersecurity" onClick={() => handleCategoryClick("Cybersecurity basics tutorial")} />
            <CategoryTile imageSrc="/images/ux-ui-icon.png" title="UX/UI Design" onClick={() => handleCategoryClick("UX UI Design complete course")} />
          </div>
        </div>
      </section>

      {/* Courses Section: Attach the ref */}
      <section ref={coursesSectionRef} className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <h3 className="text-2xl font-semibold text-blue-600 mb-2">Courses</h3>
          <h2 className="text-4xl font-bold text-gray-900 mb-12">Popular Courses for "{currentQuery}"</h2>
          {loading && <p className="text-center text-lg text-gray-700">Loading courses...</p>}
          {error && <p className="text-center text-lg text-red-500">{error}</p>}
          {!loading && !error && courses.length === 0 && (
            <p className="text-center text-lg text-gray-700">No long videos found for "{currentQuery}". Try a different category or search term.</p>
          )}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-8">
            {courses.map(course => (
              <CourseCard
                key={course.id}
                id={course.id}
                imageUrl={course.imageUrl}
                title={course.title}
                description={course.description}
                instructor={course.instructor}
                rating={course.rating}
                reviews={course.reviews}
                price={course.price}
              />
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}

export default Courses;