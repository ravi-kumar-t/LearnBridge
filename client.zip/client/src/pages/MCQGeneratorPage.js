// client/src/pages/MCQGeneratorPage.js
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';

function MCQGeneratorPage() {
  const [text, setText] = useState('');
  const [numQuestions, setNumQuestions] = useState(5); // Default to 5 questions
  const [mcqs, setMcqs] = useState([]);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState(null);

  // State to store user's selected answers for each question
  // e.g., { 0: "Paris", 1: "Mars" }
  const [selectedAnswers, setSelectedAnswers] = useState({});

  // State to control when results (correct/incorrect answers) are shown
  const [showResults, setShowResults] = useState(false);

  const navigate = useNavigate();

  const handleGenerateMCQs = async () => {
    setIsLoading(true);
    setError(null);
    setMcqs([]); // Clear previous MCQs
    setSelectedAnswers({}); // Clear selected answers
    setShowResults(false); // Hide results

    if (!text.trim()) {
      setError("Please provide text to generate MCQs.");
      setIsLoading(false);
      return;
    }
    if (isNaN(numQuestions) || numQuestions < 1 || numQuestions > 10) {
      setError("Number of questions must be between 1 and 10.");
      setIsLoading(false);
      return;
    }

    try {
      const response = await fetch('http://localhost:5000/api/generate-mcqs', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ text, numQuestions: parseInt(numQuestions) }),
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || 'Something went wrong with generating MCQs.');
      }

      const data = await response.json();
      setMcqs(data.mcqs);
    } catch (err) {
      setError(err.message);
      console.error("Error fetching MCQs:", err);
    } finally {
      setIsLoading(false);
    }
  };

  // Handler for when a user selects an option
  const handleOptionChange = (questionIndex, selectedOption) => {
    // Only allow selection if results are not already shown
    if (!showResults) {
      setSelectedAnswers(prev => ({
        ...prev,
        [questionIndex]: selectedOption,
      }));
    }
  };

  // Handler for checking answers
  const handleCheckAnswers = () => {
    setShowResults(true);
  };

  // Function to determine option style based on results
  const getOptionClass = (questionIndex, option, correctOption, userSelected) => {
    if (!showResults) return ''; // No special styling if results are not shown

    // If results are shown:
    if (option === correctOption) {
      return 'bg-green-200 text-green-800 border-green-500'; // Correct answer
    }
    if (option === userSelected && option !== correctOption) {
      return 'bg-red-200 text-red-800 border-red-500'; // User selected this and it's wrong
    }
    return ''; // Default style for other options
  };

  return (
    <div className="container mx-auto p-8 pt-16 min-h-screen bg-gray-100">
      {/* Back button */}
      <div className="flex justify-start mb-6">
        <button
          onClick={() => navigate('/explore')}
          className="flex items-center text-blue-600 hover:text-blue-800 font-medium px-4 py-2 rounded-lg border border-blue-600 hover:border-blue-800 transition-colors duration-200"
        >
          <svg className="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M10 19l-7-7m0 0l7-7m-7 7h18"></path></svg>
          Back to Explore
        </button>
      </div>

      <h1 className="text-3xl font-bold text-gray-800 mb-6 text-center">AI MCQ Generator</h1>
      <p className="text-lg text-gray-600 mb-8 text-center">
        Enter your text below to generate multiple-choice questions automatically.
      </p>

      <div className="max-w-4xl mx-auto bg-white p-8 rounded-lg shadow-md mb-8">
        <div className="mb-4">
          <label htmlFor="textInput" className="block text-gray-700 text-sm font-bold mb-2">
            Text for MCQs:
          </label>
          <textarea
            id="textInput"
            className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:ring-2 focus:ring-blue-500 h-40"
            placeholder="Paste your course material, article, or notes here..."
            value={text}
            onChange={(e) => setText(e.target.value)}
          ></textarea>
        </div>

        <div className="mb-6">
          <label htmlFor="numQuestions" className="block text-gray-700 text-sm font-bold mb-2">
            Number of Questions (1-10):
          </label>
          <input
            type="number"
            id="numQuestions"
            className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:ring-2 focus:ring-blue-500"
            value={numQuestions}
            onChange={(e) => setNumQuestions(e.target.value)}
            min="1"
            max="10"
          />
        </div>

        <div className="flex justify-center">
          <button
            onClick={handleGenerateMCQs}
            disabled={isLoading || !text.trim()}
            className={`
              bg-blue-600 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded-lg transition duration-300
              ${isLoading || !text.trim() ? 'opacity-50 cursor-not-allowed' : ''}
            `}
          >
            {isLoading ? 'Generating MCQs...' : 'Generate MCQs'}
          </button>
        </div>

        {error && (
          <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative mt-6" role="alert">
            <strong className="font-bold">Error:</strong>
            <span className="block sm:inline"> {error}</span>
          </div>
        )}
      </div>

      {mcqs.length > 0 && (
        <div className="max-w-4xl mx-auto bg-white p-8 rounded-lg shadow-md">
          <h2 className="text-2xl font-bold text-gray-800 mb-6 text-center">Generated MCQs</h2>
          {mcqs.map((mcq, qIndex) => (
            <div key={qIndex} className="mb-8 p-6 border rounded-lg shadow-sm bg-gray-50">
              <p className="text-lg font-semibold text-gray-900 mb-4">
                {qIndex + 1}. {mcq.question}
              </p>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {mcq.options.map((option, oIndex) => (
                  <label
                    key={oIndex}
                    className={`
                      flex items-center p-3 rounded-lg border cursor-pointer transition-colors duration-200
                      ${selectedAnswers[qIndex] === option ? 'bg-blue-100 border-blue-500' : 'bg-white border-gray-300 hover:bg-gray-100'}
                      ${getOptionClass(qIndex, option, mcq.answer, selectedAnswers[qIndex])}
                    `}
                  >
                    <input
                      type="radio"
                      name={`question-${qIndex}`} // Unique name for each question's radio group
                      value={option}
                      checked={selectedAnswers[qIndex] === option}
                      onChange={() => handleOptionChange(qIndex, option)}
                      disabled={showResults} // Disable input after checking answers
                      className="mr-3 h-4 w-4 text-blue-600 focus:ring-blue-500"
                    />
                    <span className="text-gray-800">{option}</span>
                  </label>
                ))}
              </div>
              {showResults && (
                <p className="mt-4 text-sm font-medium">
                  Your Answer: <span className={selectedAnswers[qIndex] === mcq.answer ? 'text-green-600' : 'text-red-600'}>
                    {selectedAnswers[qIndex] || 'Not answered'}
                  </span>
                  <br />
                  Correct Answer: <span className="text-green-600">{mcq.answer}</span>
                </p>
              )}
            </div>
          ))}
          {mcqs.length > 0 && !showResults && (
            <div className="flex justify-center mt-6">
              <button
                onClick={handleCheckAnswers}
                className="bg-green-600 hover:bg-green-700 text-white font-bold py-2 px-6 rounded-lg transition duration-300"
              >
                Check Answers
              </button>
            </div>
          )}
        </div>
      )}
    </div>
  );
}

export default MCQGeneratorPage;