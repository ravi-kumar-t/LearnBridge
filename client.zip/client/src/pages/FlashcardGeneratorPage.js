// client/src/pages/FlashcardGeneratorPage.js
// This file will now contain the main Flashcard Generator page logic

import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom'; // Assuming you need navigation as in other pages

function FlashcardGeneratorPage() { // Renamed from FlashcardGenerator
  const [inputText, setInputText] = useState('');
  const [flashcards, setFlashcards] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  // States for card navigation and flipping, as implemented in previous suggestions
  const [currentFlashcardIndex, setCurrentFlashcardIndex] = useState(0);
  const [showAnswer, setShowAnswer] = useState(false);

  const navigate = useNavigate(); // Initialize useNavigate

  const generateFlashcards = async () => {
    if (inputText.trim() === '') {
      setError('Please enter some text to generate flashcards.');
      return;
    }

    setLoading(true);
    setError('');
    setFlashcards([]); // Clear previous flashcards
    setCurrentFlashcardIndex(0); // Reset index for new set
    setShowAnswer(false); // Hide answer for new set

    try {
      // THIS IS THE CRITICAL CHANGE: Make API call to your backend
      const response = await fetch('http://localhost:5000/api/generate-flashcards', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ text: inputText }), // Send inputText as 'text' field
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || 'Something went wrong with generating flashcards from the backend.');
      }

      const data = await response.json();
      // Assuming your backend returns { flashcards: [...] }
      if (!data.flashcards || data.flashcards.length === 0) {
        setError('No flashcards could be generated from the provided text. Please try more detailed input.');
      } else {
        setFlashcards(data.flashcards);
      }

    } catch (err) {
      console.error('Error generating flashcards:', err);
      setError('Failed to generate flashcards. Please check server and try again. ' + err.message);
    } finally {
      setLoading(false);
    }
  };

  const handleNextFlashcard = () => {
    if (currentFlashcardIndex < flashcards.length - 1) {
      setCurrentFlashcardIndex(prevIndex => prevIndex + 1);
      setShowAnswer(false); // Hide answer for the next card
    }
  };

  const handlePreviousFlashcard = () => {
    if (currentFlashcardIndex > 0) {
      setCurrentFlashcardIndex(prevIndex => prevIndex - 1);
      setShowAnswer(false); // Hide answer for the previous card
    }
  };

  const currentFlashcard = flashcards[currentFlashcardIndex];


  return (
    <div className="container mx-auto p-8 pt-16 min-h-screen bg-gray-100">
      {/* Back button */}
      <div className="flex justify-start mb-6">
        <button
          onClick={() => navigate('/explore')}
          className="flex items-center text-blue-600 hover:text-blue-800 font-medium px-4 py-2 rounded-lg border border-blue-600 hover:border-blue-800 transition-colors duration-200"
        >
          <svg className="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M10 19l-7-7m0 0l7-7m-7 7h18"></path></svg>
          Back to Explore
        </button>
      </div>

      <h1 className="text-3xl font-bold text-gray-800 mb-6 text-center">AI Flashcard Generator</h1>
      <p className="text-lg text-gray-600 mb-8 text-center">
        Paste your text below to instantly generate a set of study flashcards.
      </p>


      <div className="max-w-4xl mx-auto bg-white p-8 rounded-lg shadow-md mb-8">
        <div className="mb-6">
          <label htmlFor="inputText" className="block text-lg font-medium text-gray-700 mb-2">
            Your Text/Topic:
          </label>
          <textarea
            id="inputText"
            className="w-full p-4 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500 transition duration-150 ease-in-out text-gray-800 resize-y h-40"
            placeholder="E.g., 'Photosynthesis is the process by which green plants and some other organisms use sunlight to synthesize foods from carbon dioxide and water. Photosynthesis in plants generally involves the green pigment chlorophyll and generates oxygen as a byproduct.' or 'Key concepts of Newton's Laws of Motion.'"
            value={inputText}
            onChange={(e) => setInputText(e.target.value)}
          ></textarea>
        </div>

        <button
          onClick={generateFlashcards}
          className="w-full bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 px-4 rounded-md transition duration-300 ease-in-out transform hover:scale-105 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2"
          disabled={loading || !inputText.trim()}
        >
          {loading ? (
            <span className="flex items-center justify-center">
              <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
              </svg>
              Generating...
            </span>
          ) : (
            'Generate Flashcards'
          )}
        </button>

        {error && (
          <p className="text-red-600 mt-4 text-center">{error}</p>
        )}
      </div>

      {flashcards.length > 0 && (
        <div className="max-w-xl mx-auto bg-white p-8 rounded-lg shadow-md text-center">
          <h2 className="text-2xl font-bold text-gray-800 mb-4">Your Flashcards</h2>
          <p className="text-gray-600 mb-6">Card {currentFlashcardIndex + 1} of {flashcards.length}</p>

          <div
            className="w-full h-64 flex flex-col justify-center items-center bg-blue-50 border border-blue-200 rounded-lg shadow-inner cursor-pointer"
            onClick={() => setShowAnswer(!showAnswer)}
          >
            <p className="text-xl font-semibold text-gray-800 p-4">
              {showAnswer ? currentFlashcard.answer : currentFlashcard.question}
            </p>
            <p className="text-sm text-blue-600 mt-2">
              (Click to flip)
            </p>
          </div>

          <div className="flex justify-between mt-6">
            <button
              onClick={handlePreviousFlashcard}
              disabled={currentFlashcardIndex === 0}
              className={`
                bg-gray-300 hover:bg-gray-400 text-gray-800 font-bold py-2 px-4 rounded-lg transition duration-300
                ${currentFlashcardIndex === 0 ? 'opacity-50 cursor-not-allowed' : ''}
              `}
            >
              Previous
            </button>
            <button
              onClick={handleNextFlashcard}
              disabled={currentFlashcardIndex === flashcards.length - 1}
              className={`
                bg-blue-600 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded-lg transition duration-300
                ${currentFlashcardIndex === flashcards.length - 1 ? 'opacity-50 cursor-not-allowed' : ''}
              `}
            >
              Next
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

export default FlashcardGeneratorPage; // Ensure this is the default export