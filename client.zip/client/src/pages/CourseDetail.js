// client/src/pages/CourseDetail.js
import React, { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import axios from 'axios';

// IMPORTANT: Re-use your actual YouTube Data API Key here
const YOUTUBE_API_KEY = 'AIzaSyCHd21cXOB7JLHZPWZZp_l4Th1ZZvSa9bU'; 

// NEW: Define the URL for your backend AI API
const AI_API_BASE_URL = 'http://localhost:5000'; // Your Node.js server runs on port 5000

function CourseDetail() {
  const { videoId } = useParams(); 
  const [videoDetails, setVideoDetails] = useState(null);
  const [loadingVideoDetails, setLoadingVideoDetails] = useState(true);
  const [videoDetailsError, setVideoDetailsError] = useState(null);
  const [showFullDescription, setShowFullDescription] = useState(false); 

  // NEW STATES for AI Chat
  const [currentQuestion, setCurrentQuestion] = useState(''); // Stores the question currently being typed
  const [chatHistory, setChatHistory] = useState([]); // Stores the history of questions and AI answers
  const [isAskingAI, setIsAskingAI] = useState(false); // Indicates if AI is currently processing a question
  const [aiError, setAiError] = useState(null); // Stores any errors from AI interaction

  // Correct YouTube embed URL - FIX APPLIED HERE
  const youtubeEmbedUrl = `https://www.youtube.com/embed/${videoId}?autoplay=1`; 

  // Effect to fetch video details
  useEffect(() => {
    const fetchVideoDetails = async () => {
      setLoadingVideoDetails(true);
      setVideoDetailsError(null);
      try {
        const response = await axios.get('https://www.googleapis.com/youtube/v3/videos', {
          params: {
            key: YOUTUBE_API_KEY,
            part: 'snippet,statistics', 
            id: videoId,
          },
        });

        if (response.data.items && response.data.items.length > 0) {
          setVideoDetails(response.data.items[0]);
          setShowFullDescription(false); 
          // Optionally, you might want to clear chat history when a new video loads
          setChatHistory([]); 
        } else {
          setVideoDetailsError("Video details not found.");
        }
      } catch (err) {
        console.error("Error fetching video details:", err);
        if (err.response && err.response.status === 403) {
          setVideoDetailsError("API Error: Access Forbidden. Check your API key restrictions or daily quota.");
        } else if (err.response && err.response.status === 400) {
          setVideoDetailsError("API Error: Bad Request. The video ID might be invalid.");
        } else {
          setVideoDetailsError("Failed to load video details.");
        }
      } finally {
        setLoadingVideoDetails(false);
      }
    };

    if (videoId) { 
      fetchVideoDetails();
    }
  }, [videoId]); 

  // Helper function to format large numbers for views/likes (e.g., 1234567 to 1.2M)
  const formatNumber = (num) => {
    if (num >= 1000000) {
      return (num / 1000000).toFixed(1) + 'M';
    }
    if (num >= 1000) {
      return (num / 1000).toFixed(1) + 'K';
    }
    return num;
  };

  const descriptionText = videoDetails?.snippet.description || '';
  const truncationLimit = 300; 
  const truncatedDescription = descriptionText.substring(0, truncationLimit);
  const displayDescription = showFullDescription ? descriptionText : truncatedDescription;
  const needsTruncation = descriptionText.length > truncationLimit;

  // NEW FUNCTION: Handles sending question to the backend AI API
  const handleAskAI = async () => {
    if (!currentQuestion.trim()) return; // Don't send empty questions

    const userQuestion = currentQuestion.trim();
    // Add user's question to chat history
    setChatHistory(prevHistory => [...prevHistory, { type: 'user', text: userQuestion }]);
    setCurrentQuestion(''); // Clear input field
    setIsAskingAI(true); // Set loading state
    setAiError(null); // Clear previous errors

    try {
      const response = await axios.post(`${AI_API_BASE_URL}/ask-ai`, {
        question: userQuestion,
        // You could also send videoDetails or description here for more context if your backend uses it
        // videoDescription: videoDetails?.snippet.description 
      });
      
      const aiAnswer = response.data.answer;
      // Add AI's answer to chat history
      setChatHistory(prevHistory => [...prevHistory, { type: 'ai', text: aiAnswer }]);

    } catch (err) {
      console.error("Error asking AI:", err);
      setAiError("Failed to get AI response. Please ensure your backend server is running correctly.");
      // Add an error message to chat history for user feedback
      setChatHistory(prevHistory => [...prevHistory, { type: 'error', text: "Error: Could not get AI response." }]);
    } finally {
      setIsAskingAI(false); // Reset loading state
    }
  };

  // Allow asking question on Enter key press
  const handleKeyPress = (e) => {
    if (e.key === 'Enter' && !isAskingAI) {
      handleAskAI();
    }
  };


  return (
    <div className="container mx-auto pt-6 pb-8 px-4 font-sans"> 
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        {/* Video Player Section (2/3 width on medium screens) */}
        <div className="md:col-span-2">
          <div className="bg-gray-900 rounded-lg overflow-hidden shadow-xl aspect-video mb-4">
            {videoId ? (
              <iframe
                width="100%"
                height="100%"
                src={youtubeEmbedUrl}
                title="YouTube video player"
                frameBorder="0"
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                referrerPolicy="strict-origin-when-cross-origin"
                allowFullScreen
              ></iframe>
            ) : (
              <div className="flex items-center justify-center h-full text-white">
                <p>Loading video or no video ID provided.</p>
              </div>
            )}
          </div>

          {/* Video Details Section - Similar to YouTube's layout */}
          {loadingVideoDetails ? (
            <p className="text-gray-700 p-4">Loading video details...</p>
          ) : videoDetailsError ? (
            <p className="text-red-500 p-4">{videoDetailsError}</p>
          ) : videoDetails ? (
            <div className="bg-white p-4 rounded-lg shadow-md">
              <h1 className="text-2xl font-bold text-gray-900 mb-2">{videoDetails.snippet.title}</h1>
              <div className="flex items-center text-gray-600 text-sm mb-3 flex-wrap">
                <span className="font-semibold text-blue-600 mr-2 hover:underline cursor-pointer">
                  {videoDetails.snippet.channelTitle}
                </span>
                <span className="mr-2">•</span>
                <span className="mr-2">
                  {formatNumber(videoDetails.statistics.viewCount || 0)} views
                </span>
                <span className="mr-2">•</span>
                <span>
                  Published{' '}
                  {new Date(videoDetails.snippet.publishedAt).toLocaleDateString('en-US', {
                    year: 'numeric',
                    month: 'short',
                    day: 'numeric',
                  })}
                </span>
              </div>
              <p className="text-gray-800 text-sm whitespace-pre-wrap leading-relaxed">
                {displayDescription}
                {!showFullDescription && needsTruncation && (
                  <span className="text-gray-500">...</span> 
                )}
              </p>
              {needsTruncation && (
                <button 
                  onClick={() => setShowFullDescription(!showFullDescription)}
                  className="text-blue-600 hover:underline text-sm mt-2 font-medium" 
                >
                  {showFullDescription ? 'Show less' : 'Show more'}
                </button> 
              )}
            </div>
          ) : null}
        </div>

        {/* Notes and Q&A Section (1/3 width on medium screens) */}
        <div className="md:col-span-1 bg-white p-6 rounded-lg shadow-lg flex flex-col min-h-[500px]"> 
          <h2 className="text-2xl font-semibold text-gray-900 mb-4">Your Workspace</h2>
          
          {/* Notes Area */}
          <div className="mb-6 flex-grow"> 
            <h3 className="text-xl font-medium text-gray-800 mb-2">Notes</h3>
            <textarea
              className="w-full p-3 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 resize-y min-h-[150px]"
              placeholder="Start taking notes here..."
            ></textarea>
          </div>

          {/* AI Q&A Area */}
          <div className="flex flex-col flex-grow"> 
            <h3 className="text-xl font-medium text-gray-800 mb-2">Ask AI</h3>
            {/* Chat display area - NOW displays actual chat history */}
            <div className="bg-gray-100 p-3 rounded-md mb-3 h-32 overflow-y-auto flex-grow"> 
              {chatHistory.length === 0 ? (
                <p className="text-gray-600 text-sm">AI responses will appear here. Ask a question below!</p>
              ) : (
                chatHistory.map((message, index) => (
                  <div key={index} className={`mb-2 ${message.type === 'user' ? 'text-blue-800 font-semibold' : 'text-gray-800'}`}>
                    <strong>{message.type === 'user' ? 'You:' : 'AI:'}</strong>
                    {message.type === 'ai' ? (
  // The prose classes are less effective without Markdown, but can remain if you want
  // to keep the general text styling, or you can remove this div entirely.
  <div className="prose prose-sm max-w-none">
    <p>{message.text}</p> {/* <--- CHANGED TO A SIMPLE <p> TAG */}
  </div>
) : (
  <p>{message.text}</p> // User messages remain plain text
)}
                  </div>
                ))
              )}
              {isAskingAI && (
                <p className="text-gray-500 text-sm italic">AI is thinking...</p>
              )}
              {aiError && (
                <p className="text-red-500 text-sm">{aiError}</p>
              )}
            </div>
            {/* Input field connected to state and handlers */}
            <input
              type="text"
              className="w-full p-3 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 mb-2" 
              placeholder={isAskingAI ? "AI is thinking..." : "Ask a question about the video..."}
              value={currentQuestion}
              onChange={(e) => setCurrentQuestion(e.target.value)}
              onKeyPress={handleKeyPress}
              disabled={isAskingAI} // Disable input while AI is processing
            />
            <button
              onClick={handleAskAI}
              className="bg-blue-600 hover:bg-blue-700 text-white font-semibold py-2 px-4 rounded-md transition duration-300 w-full disabled:opacity-50 disabled:cursor-not-allowed"
              disabled={isAskingAI || !currentQuestion.trim()} // Disable button if AI is thinking or input is empty
            >
              {isAskingAI ? 'Asking AI...' : 'Ask AI'}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

export default CourseDetail;