// client/src/pages/SignInPage.js
import React from "react";
import { SignIn } from "@clerk/clerk-react"; // Import Clerk's SignIn component

const SignInPage = () => {
  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-100 py-12 px-4 sm:px-6 lg:px-8">
      <SignIn routing="path" path="/sign-in" /> {/* 'path' routing and the path */}
    </div>
  );
};

export default SignInPage;