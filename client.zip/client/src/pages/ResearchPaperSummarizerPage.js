// client/src/pages/ResearchPaperSummarizerPage.js
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';

function ResearchPaperSummarizerPage() { // Renamed component
  const [inputText, setInputText] = useState('');
  const [summary, setSummary] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState(null);

  const navigate = useNavigate();

  const handleSummarize = async () => {
    setIsLoading(true);
    setError(null); // Clear previous errors
    setSummary(''); // Clear previous summary

    try {
      // IMPORTANT: Update this URL to the new research paper summarizer endpoint
      const response = await fetch('http://localhost:5000/api/summarize-research-paper', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ textToSummarize: inputText }),
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || 'Something went wrong with summarizing the research paper.');
      }

      const data = await response.json();
      setSummary(data.summary);
    } catch (err) {
      setError(err.message);
      console.error("Error fetching research paper summary:", err);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="container mx-auto p-8 pt-16 min-h-screen bg-gray-100">
      {/* Back button */}
      <div className="flex justify-start mb-6">
        <button
          onClick={() => navigate('/explore')}
          className="flex items-center text-blue-600 hover:text-blue-800 font-medium px-4 py-2 rounded-lg border border-blue-600 hover:border-blue-800 transition-colors duration-200"
        >
          <svg className="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M10 19l-7-7m0 0l7-7m-7 7h18"></path></svg>
          Back to Explore
        </button>
      </div>

      <h1 className="text-3xl font-bold text-gray-800 mb-6 text-center">AI Research Paper Summarizer</h1> {/* Updated Heading */}
      <p className="text-lg text-gray-600 mb-8 text-center">
        Paste your research paper, article, or scientific text below, and our AI will summarize its key findings, methodology, and conclusions. {/* Updated Description */}
      </p>

      <div className="max-w-3xl mx-auto bg-white p-8 rounded-lg shadow-md">
        <div className="mb-6">
          <label htmlFor="inputText" className="block text-gray-700 text-sm font-bold mb-2">
            Research Paper Text: {/* Updated Label */}
          </label>
          <textarea
            id="inputText"
            className="shadow appearance-none border rounded w-full py-3 px-4 text-gray-700 leading-tight focus:outline-none focus:ring-2 focus:ring-blue-500 h-48"
            placeholder="Enter your research paper text here..." // Updated Placeholder
            value={inputText}
            onChange={(e) => setInputText(e.target.value)}
          ></textarea>
        </div>

        <div className="flex justify-center mb-6">
          <button
            onClick={handleSummarize}
            disabled={isLoading || !inputText.trim()}
            className={`
              bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 px-6 rounded-lg transition duration-300
              ${isLoading || !inputText.trim() ? 'opacity-50 cursor-not-allowed' : ''}
            `}
          >
            {isLoading ? 'Summarizing Research Paper...' : 'Summarize Research Paper'} {/* Updated Button Text */}
          </button>
        </div>

        {error && (
          <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative mb-4" role="alert">
            <strong className="font-bold">Error:</strong>
            <span className="block sm:inline"> {error}</span>
          </div>
        )}

        {summary && (
          <div className="mt-8 p-6 bg-blue-50 border border-blue-200 rounded-lg shadow-inner">
            <h3 className="text-xl font-semibold text-blue-800 mb-4">Summary:</h3>
            <p className="text-gray-800 whitespace-pre-wrap">{summary}</p>
          </div>
        )}
      </div>
    </div>
  );
}

export default ResearchPaperSummarizerPage;