// client/src/pages/About.js
import React from 'react';
import { useNavigate } from 'react-router-dom';

function About() {
  const navigate = useNavigate();

  return (
    <div className="about-page bg-gray-50">

      {/* About Us Hero Section - Enhanced */}
      <section className="relative bg-gradient-to-r from-blue-600 to-purple-600 text-white py-20 md:py-24 overflow-hidden">
        <div className="container mx-auto px-4 text-center relative z-10">
          <p className="text-sm md:text-base font-semibold uppercase tracking-wider mb-2 opacity-80">Our Story</p>
          <h1 className="text-4xl md:text-5xl lg:text-6xl font-extrabold leading-tight mb-6">
            Connecting Minds, Shaping Futures
          </h1>
          <p className="text-lg md:text-xl max-w-4xl mx-auto mb-10 opacity-90">
            At LearnBridge, we are passionate about making quality education accessible to everyone, everywhere. We believe
            that learning is a lifelong journey, and our platform is designed to empower individuals to achieve their full potential.
          </p>
          <div className="flex justify-center space-x-4">
            <button
              onClick={() => navigate('/courses')}
              className="bg-white text-blue-600 font-semibold py-3 px-8 rounded-full shadow-lg hover:bg-gray-100 transition duration-300 transform hover:scale-105"
            >
              Explore Courses
            </button>
            <button
              onClick={() => navigate('/contact')}
              className="bg-transparent border border-white text-white font-semibold py-3 px-8 rounded-full hover:bg-white hover:text-blue-600 transition duration-300 transform hover:scale-105"
            >
              Get in Touch
            </button>
          </div>
        </div>
        {/* Subtle background graphics (optional, for visual interest) */}
        <div className="absolute top-0 left-0 w-full h-full">
            <svg className="absolute opacity-10" width="100%" height="100%" viewBox="0 0 1440 320" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M0 64L48 80C96 96 192 128 288 128C384 128 480 96 576 96C672 96 768 128 864 128C960 128 1056 96 1152 80C1248 64 1344 48 1392 40L1440 32L1440 0L1392 0C1344 0 1248 0 1152 0C1056 0 960 0 864 0C768 0 672 0 576 0C480 0 384 0 288 0C192 0 96 0 48 0L0 0Z" fill="currentColor"></path>
            </svg>
             <svg className="absolute bottom-0 right-0 opacity-10 transform rotate-180" width="100%" height="100%" viewBox="0 0 1440 320" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M0 64L48 80C96 96 192 128 288 128C384 128 480 96 576 96C672 96 768 128 864 128C960 128 1056 96 1152 80C1248 64 1344 48 1392 40L1440 32L1440 0L1392 0C1344 0 1248 0 1152 0C1056 0 960 0 864 0C768 0 672 0 576 0C480 0 384 0 288 0C192 0 96 0 48 0L0 0Z" fill="currentColor"></path>
            </svg>
        </div>
      </section>

      {/* Our Mission & Values Section */}
      <section className="py-16 md:py-24 bg-white">
        {/* Changed gap-12 to gap-8 for reduced spacing */}
        <div className="container mx-auto px-4 grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
          <div className="text-center md:text-left">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-6">Our Mission</h2>
            <p className="text-lg text-gray-700 leading-relaxed mb-4">
              Our core mission is to democratize education by making high-quality, relevant learning experiences accessible to
              everyone, regardless of their background or location. We strive to foster a global community of learners and
              educators who can share knowledge and grow together.
            </p>
            <p className="text-lg text-gray-700 leading-relaxed">
              We are committed to providing an intuitive and engaging platform where students can acquire job-ready skills,
              explore new passions, and achieve their academic and professional aspirations.
            </p>
          </div>
          <div className="flex justify-center md:justify-end">
            <img
              src="/images/flexible-learning.png"
              alt="Our Mission"
              className="rounded-lg shadow-xl w-full max-w-md object-cover border border-gray-200"
            />
          </div>
        </div>
      </section>

      {/* Why LearnBridge Section */}
      <section className="py-16 md:py-24 bg-gray-50">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">Why Choose LearnBridge?</h2>
          <p className="text-lg text-gray-700 max-w-3xl mx-auto mb-12">
            We are dedicated to providing an unparalleled learning experience with a focus on quality, flexibility, and real-world impact.
          </p>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {/* Feature Card 1 */}
            <div className="bg-white p-8 rounded-lg shadow-lg border border-gray-200 hover:shadow-xl transform hover:-translate-y-1 transition duration-300">
              <div className="text-blue-600 text-5xl mb-4">💡</div>
              <h3 className="text-xl font-semibold text-gray-900 mb-2">Expert-Led Courses</h3>
              <p className="text-gray-700">Learn from seasoned professionals and top academics who bring practical insights and deep knowledge to every lesson.</p>
            </div>
            {/* Feature Card 2 */}
            <div className="bg-white p-8 rounded-lg shadow-lg border border-gray-200 hover:shadow-xl transform hover:-translate-y-1 transition duration-300">
              <div className="text-purple-600 text-5xl mb-4">⏰</div>
              <h3 className="text-xl font-semibold text-gray-900 mb-2">Flexible Learning Paths</h3>
              <p className="text-gray-700">Access courses anytime, anywhere. Our self-paced learning model fits seamlessly into your busy schedule.</p>
            </div>
            {/* Feature Card 3 */}
            <div className="bg-white p-8 rounded-lg shadow-lg border border-gray-200 hover:shadow-xl transform hover:-translate-y-1 transition duration-300">
              <div className="text-green-600 text-5xl mb-4">🤝</div>
              <h3 className="text-xl font-semibold text-gray-900 mb-2">Vibrant Community</h3>
              <p className="text-gray-700">Connect with fellow learners, collaborate on projects, and get support from a passionate community.</p>
            </div>
          </div>
        </div>
      </section>

      {/* Call to Action Section */}
      <section className="py-16 md:py-24 bg-gradient-to-r from-blue-500 to-indigo-700 text-white text-center">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">Ready to Start Your Learning Journey?</h2>
          <p className="text-lg mb-8 max-w-2xl mx-auto opacity-90">
            Join thousands of learners who are transforming their lives with LearnBridge. Browse our extensive catalog of courses today.
          </p>
          <button
            onClick={() => navigate('/courses')}
            className="bg-white text-blue-700 font-semibold py-3 px-10 rounded-full shadow-lg hover:bg-gray-100 transition duration-300 transform hover:scale-105"
          >
            Browse All Courses
          </button>
        </div>
      </section>

      {/* Commented out: Explore Features Section (AI Flashcard Generator) as requested */}
      {/* ... (flashcard section content remains commented out) ... */}
    </div>
  );
}

export default About;