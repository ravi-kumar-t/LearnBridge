/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    "./src/**/*.{js,jsx,ts,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        'heading-purple': '#6C47FF', // From previous step
        'subheading-purple': '#7B42F6', // From previous step
        'section-light-bg': '#F8FAFC', // A very light off-white for the section background
        'card-light-bg': '#FFFFFF',   // Pure white for default card background
        'card-accent-bg': '#EDE9FE',  // Light purple for the highlighted card (like "Save money")
        'card-border': '#E0E7FF',    // A subtle light border for cards
      },
      // You can keep any existing font families here
    },
  },
  plugins: [],
}